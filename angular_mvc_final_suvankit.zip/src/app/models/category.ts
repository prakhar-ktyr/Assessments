export class Category {
    id: string;
    category: string;
    categoryDescription: string;
    constructor(id: string, c: string, cd: string) {
        this.id = id;
        this.category = c;
        this.categoryDescription = cd;
        
    }

}